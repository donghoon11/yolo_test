# Shopping Cart > 2021-11-20 12:10am
https://universe.roboflow.com/furkan-bakkal/shopping-cart-1r48s

Provided by a Roboflow user
License: CC BY 4.0

